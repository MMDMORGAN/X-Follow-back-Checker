(() => {
  'use strict';

  // توکن عمومی خود وب‌اپ X (برای همه کاربران یکسان است، رمز شخصی نیست)
  const BEARER =
    'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
  const FOLLOWS_YOU = ['follows you', 'شما را دنبال می\u200Cکند', 'شما را دنبال میکند'];
  const MIN_AGE_MS = 500; // هر اکانت حداقل این‌قدر در صفحه دیده شود تا مطمئن شویم کامل لود شده
  const STEP_MS = 900; // فاصله بین اسکرول‌ها

  /* ---------- زبان‌ها ---------- */
  const LANGS = [
    { code: 'en', name: 'English' },
    { code: 'ru', name: 'Русский' },
    { code: 'zh', name: '中文' },
    { code: 'es', name: 'Español' },
    { code: 'hi', name: 'हिन्दी' },
    { code: 'fa', name: 'فارسی' },
  ];

  const I18N = {
    en: {
      title: 'Not following back', start: 'Start scan', stop: 'Stop', copy: 'Copy text', copied: 'Copied ✓',
      download: 'Download txt', output: 'Output text', scanned: 'Scanned', notBack: 'Not following back',
      scrolling: 'Scrolling…', done: 'Scan complete', stopped: 'Stopped', count: 'Count',
      block: 'Block', unblock: 'Unblock', unfollow: 'Unfollow', unfollowed: 'Unfollowed ✓',
      errOpen: 'Error · open profile', noCt0: 'ct0 cookie not found (are you logged in?)',
      minTip: 'Collapse / expand', langTip: 'Language',
    },
    ru: {
      title: 'Не читают в ответ', start: 'Начать сканирование', stop: 'Стоп', copy: 'Копировать', copied: 'Скопировано ✓',
      download: 'Скачать txt', output: 'Текст результата', scanned: 'Просканировано', notBack: 'Не читают в ответ',
      scrolling: 'Прокрутка…', done: 'Сканирование завершено', stopped: 'Остановлено', count: 'Количество',
      block: 'Заблокировать', unblock: 'Разблокировать', unfollow: 'Отписаться', unfollowed: 'Отписано ✓',
      errOpen: 'Ошибка · открыть профиль', noCt0: 'Cookie ct0 не найден (вы вошли в аккаунт?)',
      minTip: 'Свернуть / развернуть', langTip: 'Язык',
    },
    zh: {
      title: '未回关的账号', start: '开始扫描', stop: '停止', copy: '复制文本', copied: '已复制 ✓',
      download: '下载 txt', output: '输出文本', scanned: '已扫描', notBack: '未回关',
      scrolling: '正在滚动…', done: '扫描完成', stopped: '已停止', count: '数量',
      block: '屏蔽', unblock: '取消屏蔽', unfollow: '取消关注', unfollowed: '已取消关注 ✓',
      errOpen: '出错 · 打开主页', noCt0: '未找到 ct0 cookie（是否已登录？）',
      minTip: '折叠 / 展开', langTip: '语言',
    },
    es: {
      title: 'No te siguen', start: 'Iniciar escaneo', stop: 'Detener', copy: 'Copiar texto', copied: 'Copiado ✓',
      download: 'Descargar txt', output: 'Texto de salida', scanned: 'Escaneadas', notBack: 'No te siguen',
      scrolling: 'Desplazando…', done: 'Escaneo completo', stopped: 'Detenido', count: 'Cantidad',
      block: 'Bloquear', unblock: 'Desbloquear', unfollow: 'Dejar de seguir', unfollowed: 'Dejado de seguir ✓',
      errOpen: 'Error · abrir perfil', noCt0: 'No se encontró la cookie ct0 (¿iniciaste sesión?)',
      minTip: 'Contraer / expandir', langTip: 'Idioma',
    },
    hi: {
      title: 'फ़ॉलो-बैक नहीं करने वाले', start: 'स्कैन शुरू करें', stop: 'रोकें', copy: 'टेक्स्ट कॉपी करें', copied: 'कॉपी हो गया ✓',
      download: 'txt डाउनलोड करें', output: 'आउटपुट टेक्स्ट', scanned: 'स्कैन किए गए', notBack: 'फ़ॉलो-बैक नहीं',
      scrolling: 'स्क्रोल हो रहा है…', done: 'स्कैन पूरा हुआ', stopped: 'रोका गया', count: 'संख्या',
      block: 'ब्लॉक करें', unblock: 'अनब्लॉक करें', unfollow: 'अनफ़ॉलो करें', unfollowed: 'अनफ़ॉलो किया ✓',
      errOpen: 'त्रुटि · प्रोफ़ाइल खोलें', noCt0: 'ct0 कुकी नहीं मिली (क्या आप लॉग इन हैं?)',
      minTip: 'छोटा / बड़ा करें', langTip: 'भाषा',
    },
    fa: {
      title: 'فالوبک‌نکرده‌ها', start: 'شروع اسکن', stop: 'توقف', copy: 'کپی متن', copied: 'کپی شد ✓',
      download: 'دانلود txt', output: 'متن خروجی', scanned: 'اسکن‌شده', notBack: 'فالوبک‌نکرده',
      scrolling: 'در حال اسکرول…', done: 'اسکن کامل شد', stopped: 'متوقف شد', count: 'تعداد',
      block: 'بلاک', unblock: 'رفع بلاک', unfollow: 'آنفالو', unfollowed: 'آنفالو شد ✓',
      errOpen: 'خطا · باز کردن پروفایل', noCt0: 'کوکی ct0 پیدا نشد (وارد حساب شده‌ای؟)',
      minTip: 'کوچک/بزرگ', langTip: 'زبان',
    },
  };

  let lang = 'en'; // زبان پیش‌فرض
  try {
    const saved = localStorage.getItem('fbc_lang');
    if (saved && I18N[saved]) lang = saved;
  } catch {}
  const t = (k) => I18N[lang][k];

  const S = {
    route: null,
    seen: new Map(), // key -> {key, handle, name, followsYou, firstSeen}
    rows: new Map(), // key -> row element
    blocked: new Set(),
    unfollowed: new Set(),
    failed: new Set(), // خطای بلاک
    failedUnf: new Set(), // خطای آنفالو
    scanning: false,
    timer: null,
    lastH: 0,
    stuck: 0,
    status: '', // کلید پیام وضعیت (برای ترجمه)
  };

  /* ---------- پنل ---------- */
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;top:64px;right:12px;z-index:2147483647;display:none;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
  <style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif}
    .p{width:380px;max-width:calc(100vw - 24px);max-height:82vh;display:flex;flex-direction:column;background:#16181c;color:#e7e9ea;border:1px solid #2f3336;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.45);font-size:13px}
    .hd{position:relative;display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid #2f3336;font-weight:700}
    .hd button{background:none;border:0;color:#8b98a5;font-size:18px;cursor:pointer;line-height:1}
    .tools{display:flex;align-items:center;gap:8px}
    .hd .lb{font-size:12px;font-weight:600;color:#e7e9ea;border:1px solid #2f3336;border-radius:999px;padding:3px 9px}
    .menu{position:absolute;top:100%;inset-inline-end:8px;margin-top:4px;min-width:130px;background:#16181c;border:1px solid #2f3336;border-radius:10px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.5)}
    .hd .menu button{display:block;width:100%;text-align:start;padding:8px 12px;font-size:13px;font-weight:400;color:#e7e9ea}
    .hd .menu button:hover{background:#2f3336}
    .hd .menu button.cur{color:#1d9bf0;font-weight:700}
    .bd{display:flex;flex-direction:column;gap:8px;padding:10px 12px;min-height:0}
    .bar{display:flex;gap:6px;flex-wrap:wrap}
    .b{border:0;border-radius:999px;padding:6px 12px;font-weight:700;font-size:12px;cursor:pointer;color:#fff;background:#1d9bf0}
    .b.g{background:#2f3336}
    .st{color:#8b98a5;line-height:1.7}
    .list{overflow-y:auto;max-height:300px;border:1px solid #2f3336;border-radius:10px}
    .list:empty{display:none}
    .r{display:flex;align-items:center;gap:8px;padding:6px 8px;border-bottom:1px solid #2f3336}
    .r:last-child{border-bottom:0}
    .i{flex:1;min-width:0;direction:ltr;text-align:left}
    .i a{color:#e7e9ea;font-weight:700;text-decoration:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .i small{color:#8b98a5;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .act{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:4px;max-width:220px}
    .r button{border:0;border-radius:999px;padding:5px 12px;font-size:12px;font-weight:700;cursor:pointer;background:#f4212e;color:#fff;white-space:nowrap}
    .r button.u{background:#eff3f4;color:#0f1419}
    .r button.on{background:#2f3336}
    .r button.err{background:#7a5c00}
    .r button.u.on{background:#2f3336;color:#e7e9ea}
    .r button.u.err{background:#7a5c00;color:#fff}
    .r button:disabled{opacity:.5;cursor:default}
    summary{cursor:pointer}
    textarea{width:100%;height:100px;margin-top:6px;background:#0b0d0f;color:#e7e9ea;border:1px solid #2f3336;border-radius:8px;padding:6px;direction:ltr;resize:vertical;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px}
    .hide{display:none}
  </style>
  <div class="p" id="pn">
    <div class="hd">
      <span id="ttl"></span>
      <span class="tools">
        <button class="lb" id="lang"></button>
        <button id="min">–</button>
      </span>
      <div class="menu hide" id="menu"></div>
    </div>
    <div class="bd" id="bd">
      <div class="bar">
        <button class="b" id="go"></button>
        <button class="b g" id="copy"></button>
        <button class="b g" id="dl"></button>
      </div>
      <div class="st" id="st"></div>
      <div class="list" id="list"></div>
      <details><summary class="st" id="sum"></summary><textarea id="out" readonly></textarea></details>
    </div>
  </div>`;
  document.documentElement.appendChild(host);
  const $ = (id) => root.getElementById(id);

  /* ---------- خواندن اکانت‌ها از صفحه ---------- */
  const ownHandle = () => {
    const a = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    const m = a && (a.getAttribute('href') || '').match(/^\/([A-Za-z0-9_]+)/);
    return m ? m[1].toLowerCase() : null;
  };

  function parseCell(cell) {
    let handle = null;
    for (const a of cell.querySelectorAll('a[role="link"]')) {
      const m = (a.getAttribute('href') || '').match(/^\/([A-Za-z0-9_]{1,15})$/);
      if (m) { handle = m[1]; break; }
    }
    if (!handle) return null;
    const nameEl = cell.querySelector('[data-testid="User-Name"]');
    const name = nameEl ? (nameEl.innerText || '').split('\n')[0].trim() : '';
    let followsYou = !!cell.querySelector('[data-testid="userFollowIndicator"]');
    if (!followsYou) {
      for (const sp of cell.querySelectorAll('span')) {
        if (FOLLOWS_YOU.includes((sp.textContent || '').trim().toLowerCase())) { followsYou = true; break; }
      }
    }
    return { handle, name, followsYou };
  }

  function scan() {
    const now = Date.now();
    document.querySelectorAll('[data-testid="UserCell"]').forEach((cell) => {
      const u = parseCell(cell);
      if (!u) return;
      const key = u.handle.toLowerCase();
      if (key === S.route) return;
      const rec = S.seen.get(key);
      if (!rec) S.seen.set(key, { key, handle: u.handle, name: u.name, followsYou: u.followsYou, firstSeen: now });
      else {
        if (u.followsYou) rec.followsYou = true;
        if (u.name) rec.name = u.name;
      }
    });
    render();
  }

  /* ---------- نمایش ---------- */
  function paintBlk(btn, key) {
    btn.disabled = false;
    btn.className = '';
    if (S.blocked.has(key)) { btn.textContent = t('unblock'); btn.className = 'on'; }
    else if (S.failed.has(key)) { btn.textContent = t('errOpen'); btn.className = 'err'; }
    else btn.textContent = t('block');
  }

  function paintUnf(btn, key) {
    btn.disabled = false;
    btn.className = 'u';
    if (S.unfollowed.has(key)) { btn.textContent = t('unfollowed'); btn.className = 'u on'; btn.disabled = true; }
    else if (S.failedUnf.has(key)) { btn.textContent = t('errOpen'); btn.className = 'u err'; }
    else btn.textContent = t('unfollow');
  }

  function repaint(row, key) {
    paintUnf(row.unf, key);
    paintBlk(row.blk, key);
  }

  function buildRow(r) {
    const row = document.createElement('div');
    row.className = 'r';
    const info = document.createElement('div');
    info.className = 'i';
    const a = document.createElement('a');
    a.href = `${location.origin}/${r.handle}`;
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = '@' + r.handle;
    const small = document.createElement('small');
    small.textContent = r.name;
    info.append(a, small);

    const act = document.createElement('div');
    act.className = 'act';
    const unf = document.createElement('button');
    const blk = document.createElement('button');
    row.unf = unf;
    row.blk = blk;
    unf.addEventListener('click', () => onUnfollow(r, row));
    blk.addEventListener('click', () => onBlock(r, row));
    act.append(unf, blk);

    row.append(info, act);
    repaint(row, r.key);
    return row;
  }

  const buildText = () => {
    const hs = [...S.rows.keys()].map((k) => '@' + S.seen.get(k).handle);
    return `${t('count')}: ${hs.length}\n` + hs.join('\n');
  };

  function render() {
    const now = Date.now();
    for (const r of S.seen.values()) {
      if (r.followsYou || now - r.firstSeen < MIN_AGE_MS || S.rows.has(r.key)) continue;
      const row = buildRow(r);
      S.rows.set(r.key, row);
      $('list').appendChild(row);
    }
    for (const [key, row] of S.rows) {
      if (S.seen.get(key).followsYou) { row.remove(); S.rows.delete(key); }
    }
    $('st').textContent =
      `${t('scanned')}: ${S.seen.size} | ${t('notBack')}: ${S.rows.size}` + (S.status ? ` — ${t(S.status)}` : '');
    $('out').value = buildText();
  }

  /* ---------- اسکرول خودکار ---------- */
  function tick() {
    if (!S.scanning) return;
    scan();
    const h = document.documentElement.scrollHeight;
    const atBottom = window.innerHeight + window.scrollY >= h - 4;
    S.stuck = atBottom && h === S.lastH ? S.stuck + 1 : 0;
    S.lastH = h;
    if (S.stuck >= 4) return stopScan('done');
    window.scrollBy({ top: Math.round(window.innerHeight * 0.7), behavior: 'auto' });
    S.timer = setTimeout(tick, STEP_MS);
  }

  function startScan() {
    S.scanning = true;
    S.stuck = 0;
    S.lastH = 0;
    S.status = 'scrolling';
    $('go').textContent = t('stop');
    tick();
  }

  function stopScan(msg) {
    S.scanning = false;
    clearTimeout(S.timer);
    S.status = msg || 'stopped';
    $('go').textContent = t('start');
    setTimeout(scan, MIN_AGE_MS + 100);
    render();
  }

  /* ---------- بلاک / آنفالو ---------- */
  const cookie = (n) => (document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')) || [])[1];

  async function api(endpoint, handle) {
    const ct0 = cookie('ct0');
    if (!ct0) throw new Error(t('noCt0'));
    const res = await fetch(`${location.origin}/i/api/1.1/${endpoint}.json`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        authorization: 'Bearer ' + BEARER,
        'content-type': 'application/x-www-form-urlencoded',
        'x-csrf-token': ct0,
        'x-twitter-active-user': 'yes',
        'x-twitter-auth-type': 'OAuth2Session',
        'x-twitter-client-language': 'en',
      },
      body: new URLSearchParams({ screen_name: handle }).toString(),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
  }

  async function onBlock(r, row) {
    const key = r.key;
    const btn = row.blk;
    if (S.failed.has(key)) { window.open(`${location.origin}/${r.handle}`, '_blank'); return; }
    btn.disabled = true;
    btn.textContent = '…';
    try {
      if (S.blocked.has(key)) { await api('blocks/destroy', r.handle); S.blocked.delete(key); }
      else { await api('blocks/create', r.handle); S.blocked.add(key); S.unfollowed.add(key); } // بلاک، فالو را هم برمی‌دارد
    } catch (e) {
      console.error('[followback-checker]', e);
      S.failed.add(key);
      btn.title = String(e.message || e);
    }
    repaint(row, key);
  }

  async function onUnfollow(r, row) {
    const key = r.key;
    const btn = row.unf;
    if (S.failedUnf.has(key)) { window.open(`${location.origin}/${r.handle}`, '_blank'); return; }
    btn.disabled = true;
    btn.textContent = '…';
    try {
      await api('friendships/destroy', r.handle);
      S.unfollowed.add(key);
    } catch (e) {
      console.error('[followback-checker]', e);
      S.failedUnf.add(key);
      btn.title = String(e.message || e);
    }
    repaint(row, key);
  }

  /* ---------- دکمه‌ها ---------- */
  $('go').onclick = () => (S.scanning ? stopScan() : startScan());
  $('min').onclick = () => $('bd').classList.toggle('hide');
  $('copy').onclick = async () => {
    try {
      await navigator.clipboard.writeText($('out').value);
      $('copy').textContent = t('copied');
    } catch {
      $('out').select();
      document.execCommand('copy');
    }
    setTimeout(() => ($('copy').textContent = t('copy')), 1500);
  };
  $('dl').onclick = () => {
    const url = URL.createObjectURL(new Blob(['\uFEFF' + $('out').value], { type: 'text/plain;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'not-following-back.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  /* ---------- انتخاب زبان ---------- */
  const menu = $('menu');

  function applyLang() {
    $('pn').dir = lang === 'fa' ? 'rtl' : 'ltr';
    $('ttl').textContent = t('title');
    $('go').textContent = S.scanning ? t('stop') : t('start');
    $('copy').textContent = t('copy');
    $('dl').textContent = t('download');
    $('sum').textContent = t('output');
    $('min').title = t('minTip');
    $('lang').title = t('langTip');
    $('lang').textContent = '🌐 ' + lang.toUpperCase();
    [...menu.children].forEach((b) => b.classList.toggle('cur', b.dataset.code === lang));
    for (const [key, row] of S.rows) repaint(row, key);
    render();
  }

  LANGS.forEach(({ code, name }) => {
    const b = document.createElement('button');
    b.textContent = name;
    b.dataset.code = code;
    b.addEventListener('click', () => {
      lang = code;
      try { localStorage.setItem('fbc_lang', code); } catch {}
      menu.classList.add('hide');
      applyLang();
    });
    menu.appendChild(b);
  });

  $('lang').onclick = () => menu.classList.toggle('hide');
  root.addEventListener('click', (e) => {
    if (!e.target.closest('#lang, #menu')) menu.classList.add('hide');
  });
  document.addEventListener('click', (e) => {
    if (e.target !== host) menu.classList.add('hide');
  });

  applyLang();

  /* ---------- تشخیص صفحه (X یک SPA است) ---------- */
  function resetAll() {
    stopScan('');
    S.seen.clear();
    S.rows.clear();
    S.failed.clear();
    S.failedUnf.clear();
    S.status = '';
    $('list').textContent = '';
    render();
  }

  setInterval(() => {
    const m = location.pathname.match(/^\/([A-Za-z0-9_]+)\/following\/?$/);
    const path = m ? m[1].toLowerCase() : null;
    const own = ownHandle();
    const route = path && (!own || own === path) ? path : null;
    if (route !== S.route) { S.route = route; resetAll(); }
    host.style.display = route ? 'block' : 'none';
    if (route) scan();
  }, 600);
})();
